using System;
using System.DirectoryServices.ActiveDirectory;
using System.Numerics;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using System.Runtime.Intrinsics.X86;
using System.Reflection.Metadata.Ecma335;
using System.Windows.Forms;

namespace TH04_Soccer_Teams
{
    public partial class Form1 : Form
    {
        private List<Team> teams;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            teams = new List<Team>();

            teams.Add(new Team
            {
                teamName = "Manchester United",
                teamCountry = "England",
                teamCity = "Manchester",
                Player = new List<Players>()
                {
                new Players { playerName = "Altay Bayindir", playerNum = 1, playerPos = "GK" },
                new Players { playerName = "Victor Lindel�f", playerNum = 2, playerPos = "DF" },
                new Players { playerName = "Sofyan Amrabat", playerNum = 4, playerPos = "MF" },
                new Players { playerName = "Harry Maguire", playerNum = 5, playerPos = "DF" },
                new Players { playerName = "Lisandro Mart�nez", playerNum = 6, playerPos = "DF" },
                new Players { playerName = "Mason Mount", playerNum = 7, playerPos = "MF" },
                new Players { playerName = "Bruno Fernandes", playerNum = 8, playerPos = "MF" },
                new Players { playerName = "Anthony Martial", playerNum = 9, playerPos = "FW" },
                new Players { playerName = "Rasmus H�jlund", playerNum = 11, playerPos = "FW" },
                new Players { playerName = "Marcus Rashford", playerNum = 10, playerPos = "FW" },
                new Players { playerName = "Tyrell Malacia", playerNum = 12, playerPos = "DF" },
                }
            });

            teams.Add(new Team
            {
                teamName = "Chelsea",
                teamCountry = "England",
                teamCity = "London",
                Player = new List<Players>()
                {
                new Players { playerName = "Robert S�nchez", playerNum = 1, playerPos = "GK" },
                new Players { playerName = "Axel Disasi", playerNum = 2, playerPos = "DF" },
                new Players { playerName = "Marc Cucurella", playerNum = 3, playerPos = "DF" },
                new Players { playerName = "Beno�t Badiashile", playerNum = 5, playerPos = "DF" },
                new Players { playerName = "Thiago Silva", playerNum = 6, playerPos = "DF" },
                new Players { playerName = "Raheem Sterling", playerNum = 7, playerPos = "FW" },
                new Players { playerName = "Enzo Fern�ndez", playerNum = 8, playerPos = "MF" },
                new Players { playerName = "Mykhailo Mudryk", playerNum = 10, playerPos = "FW" },
                new Players { playerName = "Noni Madueke", playerNum = 11, playerPos = "FW" },
                new Players { playerName = "Marcus Bettinelli", playerNum = 13, playerPos = "GK" },
                new Players { playerName = "Trevoh Chalobah", playerNum = 14, playerPos = "DF" },
                }
            });

            teams.Add(new Team
            {
                teamName = "Bayern Munich",
                teamCountry = "Germany",
                teamCity = "Munich",
                Player = new List<Players>()
                {
                new Players { playerName = "Manuel Neuer", playerNum = 1, playerPos = "GK" },
                new Players { playerName = "Dayot Upamecano", playerNum = 2, playerPos = "DF" },
                new Players { playerName = "Kim Min-jae", playerNum = 3, playerPos = "DF" },
                new Players { playerName = "Matthijs de Ligt", playerNum = 4, playerPos = "DF" },
                new Players { playerName = "Joshua Kimmich", playerNum = 6, playerPos = "MF" },
                new Players { playerName = "Serge Gnabry", playerNum = 7, playerPos = "FW" },
                new Players { playerName = "Leon Goretzka", playerNum = 8, playerPos = "MF" },
                new Players { playerName = "Harry Kane", playerNum = 9, playerPos = "FW" },
                new Players { playerName = "Leroy San�", playerNum = 10, playerPos = "FW" },
                new Players { playerName = "Kingsley Coman", playerNum = 11, playerPos = "FW" },
                new Players { playerName = "Eric Maxim Choupo-Moting", playerNum = 13, playerPos = "FW" },
                }
            });
            cb_country.Items.AddRange(new string[] { "England", "Germany" });
            cb_playerpos.Items.AddRange(new string[] { "GK", "DF", "MF", "FW" });
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_country.SelectedIndex >= 0)
            {
                list_namapemain.Items.Clear();
                cb_team.Text = string.Empty;
                var selectedCountry = cb_country.SelectedItem.ToString();
                var filter = teams.Where(team => team.teamCountry == selectedCountry).ToList();
                cb_team.Items.Clear();
                if (filter.Count > 0)
                {
                    cb_team.Enabled = true;
                    foreach (var team in filter)
                    {
                        cb_team.Items.Add(team.teamName);
                    }
                }
                else
                {
                    cb_team.Enabled = false;
                    list_namapemain.Items.Clear();
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_team.SelectedIndex >= 0)
            {
                var selectedTeam = cb_team.SelectedItem.ToString();
                var selectedTeamName = teams.Find(team => team.teamName == selectedTeam);
                list_namapemain.Items.Clear();
                foreach (var player in selectedTeamName.Player)
                {
                    string formattedPlayerNum = player.playerNum.ToString("D2");
                    list_namapemain.Items.Add($"({formattedPlayerNum}) {player.playerName}, {player.playerPos}");
                }
                list_namapemain.Sorted = true;
            }
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            bool exit = true;
            if (tb_teamcity.Text == "" || tb_teamcountry.Text == "" || tb_teamname.Text == "")
            {
                MessageBox.Show("Fields are not properly field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                exit = false;
            }

            foreach (var team in teams)
            {
                if (team.teamName == tb_teamname.Text)
                {
                    MessageBox.Show("Team already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    exit = false;
                }
            }
            if (exit == true)
            {
                bool add = true;
                foreach (var team in teams) //cek kalo countrynya sama, maka ga diadd ke comboboxllist
                {
                    if (tb_teamcountry.Text == team.teamCountry)
                    {
                        add = false;
                    }
                }
                if (add == true) //kalo country baru, maka di add ke combolist
                {
                    cb_country.Items.Add(tb_teamcountry.Text);
                }
                teams.Add(new Team
                {
                    teamName = tb_teamname.Text,
                    teamCountry = tb_teamcountry.Text,
                    teamCity = tb_teamcity.Text,
                    Player = new List<Players>()
                });
                tb_teamname.Text = string.Empty;
                tb_teamcountry.Text = string.Empty;
                tb_teamcity.Text = string.Empty;
                cb_country.SelectedItem = null;
            }
        }

        private void btn_addplayer_Click(object sender, EventArgs e)
        {
            if (cb_team.SelectedIndex >= 0)
            {
                var selectedTeam = cb_team.SelectedItem.ToString();
                var selectedTeamName = teams.Find(team => team.teamName == selectedTeam);
                bool exit = true;
                bool num = false;
                if (tb_playername.Text == "" || tb_playernum.Text == "" || cb_playerpos.Text == "")
                {
                    MessageBox.Show("Fields are not properly field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    exit = false;
                    num = true;
                }
                foreach (var player in selectedTeamName.Player)
                {
                    if (player.playerName == tb_playername.Text)
                    {
                        MessageBox.Show("Player name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        exit = false;
                    }
                }
                if (num == false)
                {
                    foreach (var player in selectedTeamName.Player)
                    {
                        if (player.playerNum == int.Parse(tb_playernum.Text))
                        {
                            MessageBox.Show("Player number already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            exit = false;
                        }
                    }
                }
                if (exit == true)
                {
                    selectedTeamName.Player.Add(new Players { playerName = tb_playername.Text, playerNum = int.Parse(tb_playernum.Text), playerPos = cb_playerpos.Text });
                    list_namapemain.Items.Clear();
                    foreach (var player in selectedTeamName.Player)
                    {
                        string formattedPlayerNum = player.playerNum.ToString("D2");
                        list_namapemain.Items.Add($"{formattedPlayerNum} ({player.playerPos}) {player.playerName}");
                    }
                    list_namapemain.Sorted = true;
                    tb_playername.Text = string.Empty;
                    tb_playernum.Text = string.Empty;
                }
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (cb_team.SelectedIndex >= 0)
            {
                var selectedPlayer = list_namapemain.SelectedItem.ToString();
                var selectedTeam = cb_team.SelectedItem.ToString();
                var selectedTeamName = teams.Find(team => team.teamName == selectedTeam);
                if (list_namapemain.Items.Count <= 11)
                {
                    MessageBox.Show("Unable to remove players if players are less than equal to 11.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    foreach (var team in teams)
                    {
                        foreach (var player in team.Player)
                        {
                            if ($"{player.playerNum} ({player.playerPos}) {player.playerName}" == selectedPlayer)
                            {
                                team.Player.Remove(player);
                                list_namapemain.Items.Remove(player);
                                break;
                            }
                        }
                    }
                    list_namapemain.Items.Clear();
                    foreach (var player in selectedTeamName.Player)
                    {
                        string formattedPlayerNum = player.playerNum.ToString("D2");
                        list_namapemain.Items.Add($"{formattedPlayerNum} ({player.playerPos}) {player.playerName}");
                    }
                    list_namapemain.Sorted = true;
                }
            }
        }
    }
}
