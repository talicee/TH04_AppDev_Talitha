﻿namespace TH04_Soccer_Teams
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_teamlist = new Label();
            lb_chooseteam = new Label();
            lb_choosecountry = new Label();
            cb_country = new ComboBox();
            cb_team = new ComboBox();
            list_namapemain = new ListBox();
            btn_remove = new Button();
            lb_addteam = new Label();
            lb_teamname = new Label();
            lb_teamcountry = new Label();
            lb_teamcity = new Label();
            tb_teamname = new TextBox();
            tb_teamcountry = new TextBox();
            tb_teamcity = new TextBox();
            btn_addteam = new Button();
            btn_addplayer = new Button();
            tb_playernum = new TextBox();
            tb_playername = new TextBox();
            lb_playerposition = new Label();
            lb_playernum = new Label();
            lb_playername = new Label();
            lb_addplayer = new Label();
            cb_playerpos = new ComboBox();
            SuspendLayout();
            // 
            // lb_teamlist
            // 
            lb_teamlist.AutoSize = true;
            lb_teamlist.Location = new Point(26, 28);
            lb_teamlist.Name = "lb_teamlist";
            lb_teamlist.Size = new Size(133, 25);
            lb_teamlist.TabIndex = 0;
            lb_teamlist.Text = "Score Team List";
            // 
            // lb_chooseteam
            // 
            lb_chooseteam.AutoSize = true;
            lb_chooseteam.Location = new Point(26, 116);
            lb_chooseteam.Name = "lb_chooseteam";
            lb_chooseteam.Size = new Size(127, 25);
            lb_chooseteam.TabIndex = 1;
            lb_chooseteam.Text = "Choose Team: ";
            // 
            // lb_choosecountry
            // 
            lb_choosecountry.AutoSize = true;
            lb_choosecountry.Location = new Point(26, 76);
            lb_choosecountry.Name = "lb_choosecountry";
            lb_choosecountry.Size = new Size(149, 25);
            lb_choosecountry.TabIndex = 2;
            lb_choosecountry.Text = "Choose Country: ";
            // 
            // cb_country
            // 
            cb_country.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_country.Location = new Point(181, 73);
            cb_country.Name = "cb_country";
            cb_country.Size = new Size(182, 33);
            cb_country.TabIndex = 3;
            cb_country.SelectedIndexChanged += cb_country_SelectedIndexChanged;
            // 
            // cb_team
            // 
            cb_team.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_team.Location = new Point(181, 116);
            cb_team.Name = "cb_team";
            cb_team.Size = new Size(182, 33);
            cb_team.TabIndex = 4;
            cb_team.SelectedIndexChanged += cb_team_SelectedIndexChanged;
            // 
            // list_namapemain
            // 
            list_namapemain.FormattingEnabled = true;
            list_namapemain.ItemHeight = 25;
            list_namapemain.Location = new Point(26, 166);
            list_namapemain.Name = "list_namapemain";
            list_namapemain.Size = new Size(337, 179);
            list_namapemain.TabIndex = 5;
            // 
            // btn_remove
            // 
            btn_remove.Location = new Point(26, 361);
            btn_remove.Name = "btn_remove";
            btn_remove.Size = new Size(112, 34);
            btn_remove.TabIndex = 6;
            btn_remove.Text = "Remove";
            btn_remove.UseVisualStyleBackColor = true;
            btn_remove.Click += btn_remove_Click;
            // 
            // lb_addteam
            // 
            lb_addteam.AutoSize = true;
            lb_addteam.Location = new Point(405, 28);
            lb_addteam.Name = "lb_addteam";
            lb_addteam.Size = new Size(117, 25);
            lb_addteam.TabIndex = 7;
            lb_addteam.Text = "Adding Team";
            // 
            // lb_teamname
            // 
            lb_teamname.AutoSize = true;
            lb_teamname.Location = new Point(405, 73);
            lb_teamname.Name = "lb_teamname";
            lb_teamname.Size = new Size(114, 25);
            lb_teamname.TabIndex = 8;
            lb_teamname.Text = "Team Name: ";
            // 
            // lb_teamcountry
            // 
            lb_teamcountry.AutoSize = true;
            lb_teamcountry.Location = new Point(405, 116);
            lb_teamcountry.Name = "lb_teamcountry";
            lb_teamcountry.Size = new Size(125, 25);
            lb_teamcountry.TabIndex = 9;
            lb_teamcountry.Text = "Team Country:";
            // 
            // lb_teamcity
            // 
            lb_teamcity.AutoSize = true;
            lb_teamcity.Location = new Point(405, 157);
            lb_teamcity.Name = "lb_teamcity";
            lb_teamcity.Size = new Size(97, 25);
            lb_teamcity.TabIndex = 10;
            lb_teamcity.Text = "Team City: ";
            // 
            // tb_teamname
            // 
            tb_teamname.Location = new Point(539, 70);
            tb_teamname.Name = "tb_teamname";
            tb_teamname.Size = new Size(150, 31);
            tb_teamname.TabIndex = 11;
            // 
            // tb_teamcountry
            // 
            tb_teamcountry.Location = new Point(539, 113);
            tb_teamcountry.Name = "tb_teamcountry";
            tb_teamcountry.Size = new Size(150, 31);
            tb_teamcountry.TabIndex = 12;
            // 
            // tb_teamcity
            // 
            tb_teamcity.Location = new Point(539, 157);
            tb_teamcity.Name = "tb_teamcity";
            tb_teamcity.Size = new Size(150, 31);
            tb_teamcity.TabIndex = 13;
            // 
            // btn_addteam
            // 
            btn_addteam.Location = new Point(490, 209);
            btn_addteam.Name = "btn_addteam";
            btn_addteam.Size = new Size(112, 34);
            btn_addteam.TabIndex = 14;
            btn_addteam.Text = "Add";
            btn_addteam.UseVisualStyleBackColor = true;
            btn_addteam.Click += btn_addteam_Click;
            // 
            // btn_addplayer
            // 
            btn_addplayer.Location = new Point(804, 212);
            btn_addplayer.Name = "btn_addplayer";
            btn_addplayer.Size = new Size(112, 34);
            btn_addplayer.TabIndex = 22;
            btn_addplayer.Text = "Add";
            btn_addplayer.UseVisualStyleBackColor = true;
            btn_addplayer.Click += btn_addplayer_Click;
            // 
            // tb_playernum
            // 
            tb_playernum.Location = new Point(853, 116);
            tb_playernum.Name = "tb_playernum";
            tb_playernum.Size = new Size(150, 31);
            tb_playernum.TabIndex = 20;
            // 
            // tb_playername
            // 
            tb_playername.Location = new Point(853, 73);
            tb_playername.Name = "tb_playername";
            tb_playername.Size = new Size(150, 31);
            tb_playername.TabIndex = 19;
            // 
            // lb_playerposition
            // 
            lb_playerposition.AutoSize = true;
            lb_playerposition.Location = new Point(719, 160);
            lb_playerposition.Name = "lb_playerposition";
            lb_playerposition.Size = new Size(136, 25);
            lb_playerposition.TabIndex = 18;
            lb_playerposition.Text = "Player Position: ";
            // 
            // lb_playernum
            // 
            lb_playernum.AutoSize = true;
            lb_playernum.Location = new Point(719, 119);
            lb_playernum.Name = "lb_playernum";
            lb_playernum.Size = new Size(138, 25);
            lb_playernum.TabIndex = 17;
            lb_playernum.Text = "Player Number: ";
            // 
            // lb_playername
            // 
            lb_playername.AutoSize = true;
            lb_playername.Location = new Point(719, 76);
            lb_playername.Name = "lb_playername";
            lb_playername.Size = new Size(120, 25);
            lb_playername.TabIndex = 16;
            lb_playername.Text = "Player Name: ";
            // 
            // lb_addplayer
            // 
            lb_addplayer.AutoSize = true;
            lb_addplayer.Location = new Point(719, 31);
            lb_addplayer.Name = "lb_addplayer";
            lb_addplayer.Size = new Size(131, 25);
            lb_addplayer.TabIndex = 15;
            lb_addplayer.Text = "Adding Players";
            // 
            // cb_playerpos
            // 
            cb_playerpos.DropDownStyle = ComboBoxStyle.DropDownList;
            cb_playerpos.Location = new Point(853, 157);
            cb_playerpos.Name = "cb_playerpos";
            cb_playerpos.Size = new Size(93, 33);
            cb_playerpos.TabIndex = 23;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1046, 450);
            Controls.Add(cb_playerpos);
            Controls.Add(btn_addplayer);
            Controls.Add(tb_playernum);
            Controls.Add(tb_playername);
            Controls.Add(lb_playerposition);
            Controls.Add(lb_playernum);
            Controls.Add(lb_playername);
            Controls.Add(lb_addplayer);
            Controls.Add(btn_addteam);
            Controls.Add(tb_teamcity);
            Controls.Add(tb_teamcountry);
            Controls.Add(tb_teamname);
            Controls.Add(lb_teamcity);
            Controls.Add(lb_teamcountry);
            Controls.Add(lb_teamname);
            Controls.Add(lb_addteam);
            Controls.Add(btn_remove);
            Controls.Add(list_namapemain);
            Controls.Add(cb_team);
            Controls.Add(cb_country);
            Controls.Add(lb_choosecountry);
            Controls.Add(lb_chooseteam);
            Controls.Add(lb_teamlist);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lb_teamlist;
        private Label lb_chooseteam;
        private Label lb_choosecountry;
        private ComboBox cb_country;
        private ComboBox cb_team;
        private ListBox list_namapemain;
        private Button btn_remove;
        private Label lb_addteam;
        private Label lb_teamname;
        private Label lb_teamcountry;
        private Label lb_teamcity;
        private TextBox tb_teamname;
        private TextBox tb_teamcountry;
        private TextBox tb_teamcity;
        private Button btn_addteam;
        private Button btn_addplayer;
        private TextBox tb_playernum;
        private TextBox tb_playername;
        private Label lb_playerposition;
        private Label lb_playernum;
        private Label lb_playername;
        private Label lb_addplayer;
        private ComboBox cb_playerpos;
    }
}