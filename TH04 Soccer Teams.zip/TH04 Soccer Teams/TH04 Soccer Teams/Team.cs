﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Soccer_Teams
{
    internal class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Players> Player = new List<Players>();

    }
}
