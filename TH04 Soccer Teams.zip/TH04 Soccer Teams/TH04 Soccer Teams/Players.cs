﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_Soccer_Teams
{
    internal class Players
    {
        public string playerName { get; set; }
        public int playerNum { get; set; }
        public string playerPos{ get; set; }

    }
}
